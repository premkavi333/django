from django.urls import path
from . import views

urlpatterns = [
    path('my-profile/', views.my_profile, name='my_profile'),
    path('change-password/', views.change_password, name='change_password'),
    path('profile-picture/', views.profile_picture, name='profile_picture'),
    path('welcome-letter/', views.welcome_letter, name='welcome_letter'),
    path('transaction-password/', views.transaction_password, name='transaction_password'),
    path('visiting-card/', views.visiting_card, name='visiting_card'),
    path('id-card/', views.id_card, name='id_card'),
]