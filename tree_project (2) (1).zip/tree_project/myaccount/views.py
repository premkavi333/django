from django.shortcuts import render

def my_profile(request):
    return render(request, 'myaccount/my_profile.html')

def change_password(request):
    return render(request, 'myaccount/change_password.html')

def profile_picture(request):
    return render(request, 'myaccount/profile_picture.html')

def welcome_letter(request):
    return render(request, 'myaccount/welcome_letter.html')

def transaction_password(request):
    return render(request, 'myaccount/transaction_password.html')

def visiting_card(request):
    return render(request, 'myaccount/visiting_card.html')

def id_card(request):
    return render(request, 'myaccount/id_card.html')
