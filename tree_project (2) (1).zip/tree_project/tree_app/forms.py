# tree_app/forms.py

from django import forms
from .models import UserProfile 
from .models import Category, Product

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = '__all__'  # or specify like ['name', 'email', 'phone']
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
        }


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'image']


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            'name',
            'description',
            'category',
            'image',
            'pv_point',
            'dp_price',
            'mrp_price',
            'gst_percentage',
            'size',
            'available_stock',
            'is_active',
        ]
