from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from tree_app.models import TreeNode

class Command(BaseCommand):
    help = 'Create test tree data'

    def handle(self, *args, **kwargs):
        if User.objects.filter(username='root').exists():
            self.stdout.write(self.style.WARNING('Test data already exists'))
            return

        root_user = User.objects.create_user(username='root', password='password123')
        child1_user = User.objects.create_user(username='child1', password='password123')
        child2_user = User.objects.create_user(username='child2', password='password123')
        child3_user = User.objects.create_user(username='child3', password='password123')

        root_node = TreeNode.objects.create(user=root_user)
        TreeNode.objects.create(user=child1_user, parent=root_node)
        TreeNode.objects.create(user=child2_user, parent=root_node)
        TreeNode.objects.create(user=child3_user, parent=root_node)

        self.stdout.write(self.style.SUCCESS('Test tree data created successfully'))
