# tree_app/models.py
from django.contrib.auth.models import User
from django.db import models
from django.db.models import Q  # add this if not already
from users.models import UserProfile

class TreeNode(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL, related_name='children')

    def __str__(self):
        return self.user.username
    
    
# tree_app/models.py

class Category(models.Model):
    name = models.CharField(max_length=255)
    image = models.ImageField(upload_to='category_images/', blank=True, null=True)

    def __str__(self):
        return self.name



class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='product_images/', blank=True, null=True)

    pv_point = models.DecimalField(max_digits=10, decimal_places=2)  # replaces `price`
    dp_price = models.DecimalField(max_digits=10, decimal_places=2)
    mrp_price = models.DecimalField(max_digits=10, decimal_places=2)
    gst_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)  # in percent (e.g., 5.00)

    size = models.DecimalField(max_digits=10, decimal_places=2, default=1)  # required for USP

    available_stock = models.PositiveIntegerField()
    is_active = models.BooleanField(default=True)

    @property
    def usp(self):
        try:
            return self.mrp_price / self.size
        except ZeroDivisionError:
            return 0

    @property
    def unit_price(self):
        # gst_amount = (gst% of dp_price)
        gst_amount = (self.gst_percentage / 100) * self.dp_price
        return self.dp_price - gst_amount
    
    @property
    def gst_price(self):
        return round((self.mrp_price * self.gst_percentage) / 100, 2)

    def __str__(self):
        return self.name
    



