from django.urls import path
from . import views

app_name = 'tree_app'

urlpatterns = [

    path('dashboard/', views.dashboard, name='dashboard'),
    path('see-my-tree/', views.see_my_tree, name='see_my_tree'),
    path('add-user/', views.add_user_in_tree, name='add_user'),
    path('org-chart/', views.organization_chart, name='org_chart'),
    path('logout/', views.logout_view, name='logout'),
    path('login/', views.login_view, name='login'),
    path('user-management/', views.admin_user_management, name='admin_user_management'),
    path('toggle-user-status/<int:user_id>/', views.toggle_user_status, name='toggle_user_status'),
    path('edit-user/<int:pk>/', views.edit_user, name='edit_user'),
    path('view-profile/<int:user_id>/', views.view_user_profile, name='view_user_profile'),
    path('user/<int:user_id>/kyc/', views.admin_user_kyc_detail, name='admin_user_kyc_detail'),
    path('delete-kyc/<int:kyc_id>/', views.delete_kyc_view, name='delete_kyc'),
    path('create-category/', views.create_category, name='create_category'),
    path('categories/', views.list_categories, name='list_categories'),
    path('create-product/', views.create_product, name='create_product'),
    path('products/', views.list_products, name='list_products'),
    path('admin-orders/', views.admin_order_management, name='admin_order_management'),
    path('update-order-status/<int:order_id>/', views.update_order_status, name='update_order_status'),


]