# tree_app/views.py
# tree_app/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import TreeNode
from users.models import UserProfile, Order  # ✅ Make sure this is the correct path
from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.timezone import now
from .forms import UserProfileForm
from .forms import CategoryForm, ProductForm
from .models import Category, Product
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Sum


import logging
logger = logging.getLogger(__name__)
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            try:
                profile = user.userprofile
                if profile.role == 1:
                    return redirect('tree_app:dashboard')  # Admin Dashboard
                else:
                    return redirect('users:dashboard')     # User Dashboard
            except UserProfile.DoesNotExist:
                messages.error(request, "User profile not found.")
                return redirect('tree_app:login')
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('tree_app:login')

    return render(request, 'login.html')

@login_required
def admin_user_kyc_detail(request, user_id):
    user = get_object_or_404(User, id=user_id)
    kyc = KYC.objects.filter(user=user).first()  # type: ignore # Assume one KYC per user

    return render(request, 'admin/user_kyc_detail.html', {
        'kyc': kyc,
        'user_obj': user,
    })


@login_required
def dashboard(request):
    user = request.user

    # Agar user ke liye node already DB me hai to use fetch karo
    try:
        node = TreeNode.objects.get(user=user)
    except TreeNode.DoesNotExist:
        node = None  # ya redirect, ya error dikhao, jo chaho

    return render(request, 'dashboard.html', {'node': node})


@login_required
def see_my_tree(request):
    node, created = TreeNode.objects.get_or_create(user=request.user)
    children = node.children.all()

    return render(request, 'see_my_tree.html', {
        'node': node,
        'children': children,
    })
@login_required
def add_user_in_tree(request):
    if request.method == 'POST':
        name = request.POST['name']
        parent_id = request.POST.get('parent_id')

        if parent_id:
            parent = TreeNode.objects.get(id=parent_id)
        else:
            parent = None

        TreeNode.objects.create(name=name, parent=parent)
        return redirect('dashboard')

    # GET request — show form
    nodes = TreeNode.objects.all()
    return render(request, 'add_user.html', {'nodes': nodes})

@login_required
def organization_chart(request):
    root = TreeNode.objects.filter(parent=None).first()
    return render(request, 'org_chart.html', {'root': root})

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('tree_app:login')


@staff_member_required
def admin_user_management(request):
    active_users = User.objects.filter(userprofile__activation_date__isnull=False).order_by('-date_joined')
    inactive_users = User.objects.filter(userprofile__activation_date__isnull=True).order_by('-date_joined')
    
    return render(request, 'user_management.html', {
        'active_users': active_users,
        'inactive_users': inactive_users,
    })

@login_required
def toggle_user_status(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    try:
        profile = user.userprofile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=user)

    if profile.activation_date:
        profile.activation_date = None
    else:
        profile.activation_date = now()

    profile.save()
    return redirect('tree_app:admin_user_management')


def view_user_profile(request, user_id):
    profile = get_object_or_404(UserProfile, user__id=user_id)
    return render(request, 'user_profile_view.html', {'profile': profile})

def edit_user(request, pk):
    profile = get_object_or_404(UserProfile, pk=pk)
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('tree_app:view_user_profile', pk=pk)
    else:
        form = UserProfileForm(instance=profile)
    
    return render(request, 'edit_user.html', {'form': form, 'profile': profile})

@login_required
def delete_kyc_view(request, kyc_id):
    kyc = get_object_or_404(KYC, id=kyc_id) # type: ignore
    user_id = kyc.user.id  # Save user ID to redirect back
    kyc.delete()
    messages.success(request, "✅ KYC deleted successfully.")
    return redirect('admin_user_kyc_detail', user_id=user_id)



def create_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('tree_app:list_categories')
    else:
        form = CategoryForm()
    return render(request, 'create_category.html', {'form': form})

def list_categories(request):
    categories = Category.objects.all()
    return render(request, 'list_categories.html', {'categories': categories})

def create_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('tree_app:list_products')
    else:
        form = ProductForm()
    return render(request, 'create_product.html', {'form': form})

def list_products(request):
    products = Product.objects.select_related('category').all()
    return render(request, 'list_products.html', {'products': products})

@user_passes_test(lambda u: u.is_superuser)
def admin_order_management(request):
    status_choices = Order.STATUS_CHOICES
    status_labels = {key: label for key, label in status_choices}

    # Group orders by status
    orders_by_status = {
        key: Order.objects.filter(status=key).order_by('-id')
        for key in status_labels.keys()
    }

    context = {
        'status_choices': status_choices,
        'orders_by_status': orders_by_status,
        'status_labels': status_labels
    }
    return render(request, 'admin_order_management.html', context)

@user_passes_test(lambda u: u.is_superuser)
def update_order_status(request, order_id):
    if request.method == 'POST':
        order = get_object_or_404(Order, id=order_id)
        new_status = request.POST.get('status')
        if new_status in dict(Order.STATUS_CHOICES):
            order.status = new_status
            order.save()
    return redirect('tree_app:admin_order_management')

