from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import UserProfile, ShippingAddress
import re

# ----------------------
# Signup Form
# ----------------------
class SignupForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        label="Username",
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'style': 'border-radius: 12px; padding: 10px 15px;',
            'placeholder': 'Username'
        })
    )
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'style': 'border-radius: 12px; padding: 10px 15px;',
            'placeholder': 'Email'
        })
    )
    password = forms.CharField(
        label="Password",
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'style': 'border-radius: 12px; padding: 10px 15px;',
            'placeholder': 'Password'
        })
    )

# ----------------------
# User Profile Form
# ----------------------
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        exclude = ['user', 'activation_date', 'role', 'distributor_ird', 'place_under']
        widgets = {
            'gender': forms.Select(attrs={'class': 'form-control', 'style': 'border-radius: 12px; padding: 10px 15px;'}),
            'id_proof_type': forms.Select(attrs={'class': 'form-control', 'style': 'border-radius: 12px; padding: 10px 15px;'}),
            'birth_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'style': 'border-radius: 12px; padding: 10px 15px;'}),
            'nominee_birth_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'style': 'border-radius: 12px; padding: 10px 15px;'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.setdefault('class', 'form-control')
            field.widget.attrs.setdefault('style', 'border-radius: 12px; padding: 10px 15px;')

        for field in ['sponsor_id', 'sponsor_name', 'sponsor_position']:
            if field in self.fields:
                self.fields[field].widget.attrs['readonly'] = True

    def clean_mobile(self):
        mobile = self.cleaned_data.get('mobile')
        if not re.match(r'^\d{10}$', mobile):
            raise forms.ValidationError("Enter a valid 10-digit mobile number.")
        return mobile

    def clean(self):
        cleaned_data = super().clean()
        sponsor_id = cleaned_data.get('sponsor_id')
        sponsor_position = cleaned_data.get('sponsor_position')

        if sponsor_id:
            try:
                sponsor_user = User.objects.get(id=sponsor_id)
                sponsor_name = sponsor_user.get_full_name() or sponsor_user.username
                cleaned_data['sponsor_name'] = sponsor_name
            except User.DoesNotExist:
                raise ValidationError(f"No parent user found with Sponsor ID '{sponsor_id}'.")

            left_count = UserProfile.objects.filter(sponsor_id=sponsor_id, sponsor_position='Left').count()
            right_count = UserProfile.objects.filter(sponsor_id=sponsor_id, sponsor_position='Right').count()

            if sponsor_position:
                if sponsor_position == 'Left' and left_count >= 1:
                    if right_count < 1:
                        raise ValidationError("Left leg is full. Please use Right.")
                    else:
                        raise ValidationError("Both legs are full. Please change Sponsor ID.")
                elif sponsor_position == 'Right' and right_count >= 1:
                    if left_count < 1:
                        raise ValidationError("Right leg is full. Please use Left.")
                    else:
                        raise ValidationError("Both legs are full. Please change Sponsor ID.")
            else:
                available = []
                if left_count < 1:
                    available.append('Left')
                if right_count < 1:
                    available.append('Right')
                if available:
                    raise ValidationError(f"Available legs under Sponsor ID '{sponsor_id}': {', '.join(available)}. Please select one.")
                else:
                    raise ValidationError(f"Both legs under Sponsor ID '{sponsor_id}' are already filled. Please choose another Sponsor ID.")

        return cleaned_data

# ----------------------
# Bank Details Form
# ----------------------
class BankDetailsForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['account_holder', 'bank_name', 'branch_name', 'account_number', 'ifsc_code', 'passbook_image']
        widgets = {
            'account_holder': forms.TextInput(attrs={'class': 'form-control'}),
            'bank_name': forms.TextInput(attrs={'class': 'form-control'}),
            'branch_name': forms.TextInput(attrs={'class': 'form-control'}),
            'account_number': forms.TextInput(attrs={'class': 'form-control'}),
            'ifsc_code': forms.TextInput(attrs={'class': 'form-control'}),
        }

# ----------------------
# PAN Card Form
# ----------------------
class PanCardForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['pan_card', 'pan_card_image']

# ----------------------
# GST Form
# ----------------------
class GSTForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['gst_no', 'gst_image']

# ----------------------
# ID Proof Form
# ----------------------
class IDForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['id_proof_type', 'id_proof_no', 'back_copy', 'front_copy']

# ----------------------
# Shipping Address Form
# ----------------------
class ShippingAddressForm(forms.ModelForm):
    STATE_CHOICES = [
        ('Andhra Pradesh', 'Andhra Pradesh'),
        ('Arunachal Pradesh', 'Arunachal Pradesh'),
        ('Assam', 'Assam'),
        ('Bihar', 'Bihar'),
        ('Chhattisgarh', 'Chhattisgarh'),
        ('Goa', 'Goa'),
        ('Gujarat', 'Gujarat'),
        ('Haryana', 'Haryana'),
        ('Himachal Pradesh', 'Himachal Pradesh'),
        ('Jharkhand', 'Jharkhand'),
        ('Karnataka', 'Karnataka'),
        ('Kerala', 'Kerala'),
        ('Madhya Pradesh', 'Madhya Pradesh'),
        ('Maharashtra', 'Maharashtra'),
        ('Manipur', 'Manipur'),
        ('Meghalaya', 'Meghalaya'),
        ('Mizoram', 'Mizoram'),
        ('Nagaland', 'Nagaland'),
        ('Odisha', 'Odisha'),
        ('Punjab', 'Punjab'),
        ('Rajasthan', 'Rajasthan'),
        ('Sikkim', 'Sikkim'),
        ('Tamil Nadu', 'Tamil Nadu'),
        ('Telangana', 'Telangana'),
        ('Tripura', 'Tripura'),
        ('Uttar Pradesh', 'Uttar Pradesh'),
        ('Uttarakhand', 'Uttarakhand'),
        ('West Bengal', 'West Bengal'),
        ('Andaman and Nicobar Islands', 'Andaman and Nicobar Islands'),
        ('Chandigarh', 'Chandigarh'),
        ('Dadra and Nagar Haveli and Daman and Diu', 'Dadra and Nagar Haveli and Daman and Diu'),
        ('Delhi', 'Delhi'),
        ('Jammu and Kashmir', 'Jammu and Kashmir'),
        ('Ladakh', 'Ladakh'),
        ('Lakshadweep', 'Lakshadweep'),
        ('Puducherry', 'Puducherry'),
    ]

    state = forms.ChoiceField(choices=STATE_CHOICES, widget=forms.Select(attrs={'class': 'form-control'}))

    class Meta:
        model = ShippingAddress
        exclude = ['user']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.TextInput(attrs={'class': 'form-control'}),
            'city': forms.TextInput(attrs={'class': 'form-control'}),
            'pin_code': forms.TextInput(attrs={'class': 'form-control'}),
            'mobile_no': forms.TextInput(attrs={'class': 'form-control'}),
            'alt_mobile_no': forms.TextInput(attrs={'class': 'form-control'}),
            'landmark': forms.TextInput(attrs={'class': 'form-control'}),
        }
