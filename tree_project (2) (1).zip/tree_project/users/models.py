# users/models.py
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db.models import Sum


GENDER_CHOICES = (
    ('Male', 'Male'),
    ('Female', 'Female'),
    ('Others', 'Others'),
)

ID_PROOF_CHOICES = (
    ('Aadhar', 'Aadhar'),
    ('VoterId', 'Voter ID'),
    ('Passport', 'Passport'),
    ('DrivingLicense', 'Driving License'),
)

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # link to auth user
    sponsor_id = models.CharField(max_length=20)
    sponsor_name = models.CharField(max_length=100)
    sponsor_position = models.CharField(max_length=10, choices=(('Left', 'Left'), ('Right', 'Right')), blank=True, null=True)
    place_under = models.CharField(max_length=100 , blank=True, null=True)
    distributor_ird = models.CharField(max_length=20, blank=True, null=True)
    name = models.CharField(max_length=100)
    birth_date = models.DateField()
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default='Male')
    father_name = models.CharField(max_length=100)
    join_date = models.DateTimeField(auto_now_add=True)
    activation_date = models.DateTimeField(null=True, blank=True)
    mobile_no = models.CharField(max_length=15)
    email = models.EmailField(blank=True)
    whatsapp_no = models.CharField(max_length=15, blank=True)
    address1 = models.TextField()
    address2 = models.TextField(blank=True)
    city = models.CharField(max_length=100)
    district = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin_code = models.CharField(max_length=10)
    nominee_name = models.CharField(max_length=100)
    nominee_birth_date = models.DateField()
    nominee_relation = models.CharField(max_length=50)
    account_holder = models.CharField(max_length=100)
    bank_name = models.CharField(max_length=100)
    branch_name = models.CharField(max_length=100)
    account_number = models.CharField(max_length=20)
    ifsc_code = models.CharField(max_length=15)
    id_proof_type = models.CharField(max_length=20, choices=ID_PROOF_CHOICES, blank=True, null=True)
    id_proof_no = models.CharField(max_length=50, blank=True, null=True)
    role = models.IntegerField(default=0)  # 0 = user, 1 = admin
    passbook_image = models.ImageField(upload_to='passbook_images/', null=True, blank=True)
    pan_card = models.CharField(max_length=15, blank=True, null=True)
    pan_card_image = models.ImageField(upload_to='kyc/pan/', blank=True, null=True)
    gst_no = models.CharField(max_length=15, blank=True, null=True)
    gst_image = models.ImageField(upload_to='kyc/gst/', blank=True, null=True)
    front_copy = models.ImageField(upload_to='kyc/aadhaar/front/', blank=True, null=True)
    back_copy = models.ImageField(upload_to='kyc/aadhaar/back/', blank=True, null=True)
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True)


    def __str__(self):
        return self.name
    

    
@receiver(post_save, sender=UserProfile)
def generate_distributor_ird(sender, instance, created, **kwargs):
    if created and not instance.distributor_ird:
        last_profile = UserProfile.objects.exclude(distributor_ird__isnull=True).order_by('-id').first()
        if last_profile and last_profile.distributor_ird:
            # Extract digits safely
            numeric_part = ''.join(filter(str.isdigit, last_profile.distributor_ird))
            last_number = int(numeric_part) if numeric_part else 0
        else:
            last_number = 0

        new_number = last_number + 1
        instance.distributor_ird = f"HW{new_number:05d}"  # e.g., HW00001, HW00002
        instance.save()

    
class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey('tree_app.Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)  # ✅ Add this
    added_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"
    

class ShippingAddress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    address = models.TextField()
    state = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    pin_code = models.CharField(max_length=6)
    mobile_no = models.CharField(max_length=10)
    alt_mobile_no = models.CharField(max_length=10, blank=True, null=True)
    landmark = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.name} - {self.city}"
  

class UserRankStat(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    current_rank = models.CharField(max_length=100, default='Newbie')
    left_point = models.IntegerField(default=0)
    right_point = models.IntegerField(default=0)
    total_match = models.IntegerField(default=0)
    team_no = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.user.username} - {self.current_rank}"
    


class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('processing', 'Processing'),
        ('delivered', 'Delivered'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    payment_method = models.CharField(max_length=50, default='upi')
    payment_receipt = models.FileField(upload_to='payment_receipts/', blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    is_ordered = models.BooleanField(default=False) 
    pv = models.DecimalField(max_digits=10, decimal_places=2, default=0)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey('tree_app.Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    pv_point = models.DecimalField(max_digits=10, decimal_places=2)



class PvPoint(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    self_pv = models.PositiveIntegerField(default=0)
    left_pv = models.PositiveIntegerField(default=0)
    right_pv = models.PositiveIntegerField(default=0)

    def team_pv(self):
        return self.self_pv + self.left_pv + self.right_pv

    def __str__(self):
        return f"{self.user.username} PV"
    
def apply_pv_points(order):
    for item in order.orderitem_set.all():
        product = item.product
        quantity = item.quantity
        total_pv = product.pv_point * quantity  # Field aapne product me add ki thi

        # Add to user's self PV
        pv_obj, _ = PvPoint.objects.get_or_create(user=order.user)
        pv_obj.self_pv += total_pv
        pv_obj.save()

        # Now propagate to parents
        propagate_pv_to_parents(order.user, total_pv)


def propagate_pv_to_parents(user, total_pv):
    current_tree = UserTree.objects.filter(user=user).first()
    while current_tree and current_tree.parent:
        parent = current_tree.parent
        position = current_tree.position  # left or right

        parent_pv, _ = PvPoint.objects.get_or_create(user=parent)
        if position == 'left':
            parent_pv.left_pv += total_pv
        else:
            parent_pv.right_pv += total_pv

        parent_pv.save()
        current_tree = UserTree.objects.filter(user=parent).first()


# users/models.py

class UserTree(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='tree')
    parent = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='children')
    position = models.CharField(max_length=10, choices=(('left', 'Left'), ('right', 'Right')))

    def __str__(self):
        return f"{self.user.username} under {self.parent.username if self.parent else 'None'}"
    

class Payout(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    payout_code = models.CharField(max_length=10)  # e.g., 0001
    from_date = models.DateField()
    to_date = models.DateField()
    left_point = models.IntegerField(default=0)
    right_point = models.IntegerField(default=0)
    match_point = models.IntegerField(default=0)
    total_match = models.IntegerField(default=0)
    remmaning_point = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.payout_code} ({self.from_date} to {self.to_date})"
    

class PVRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    left_pv = models.IntegerField(default=0)
    right_pv = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.user.username} - {self.date}"
    
    