from django.urls import path
from . import views
from django.views.generic import TemplateView

app_name = 'users'

urlpatterns = [
  path('dashboard/', views.dashboard, name='dashboard'),
    
    # My Account
    path('my-profile/', views.my_profile, name='my_profile'),
    path('change-password/', views.change_password, name='change_password'),
    path('profile-picture/', views.profile_picture, name='profile_picture'),
    path('welcome-letter/', views.welcome_letter, name='welcome_letter'),
    path('download-welcome-letter/', views.download_welcome_letter_pdf, name='download_welcome_letter'),
    path('transaction-password/', views.transaction_password, name='transaction_password'),
    path('visiting-card/', views.visiting_card, name='visiting_card'),
    path('download-card/', views.download_card_pdf, name='download_card_pdf'),
    path('id-card/', views.id_card, name='id_card'),
    path('signup/', views.signup_view, name='signup'),
    path('signup-success/', views.signup_success, name='signup-success'),
    path('logout/', views.logout_view, name='logout'),
    path('update-bank-details/', views.update_bank_details, name='update_bank_details'),
    path('upload-pan-card/', views.upload_pan_card, name='upload_pan_card'),
    path('upload-gst/', views.upload_gst, name='upload_gst'),
    path('upload-id-proof/', views.upload_id_proof, name='upload_id_proof'),
    path('upload-profile-picture/', views.upload_profile_picture, name='upload_profile_picture'),
    path('order-now/', views.order_now, name='order_now'),
    path('shop/', views.shop_home, name='shop_home'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'), 
    path('cart/', views.view_cart, name='view_cart'),
    path('cart/remove/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/update/<int:product_id>/', views.update_cart_quantity, name='update_cart_quantity'),
    path('my-team/', views.my_team_view, name='my_team'),
    path('current-rank/', views.current_rank_view, name='current_rank'),
    path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/remove/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/update/<int:product_id>/', views.update_cart_quantity, name='update_cart_quantity'),

    
    
    # Confirm checkout (POST handler)
    path('confirm-checkout/', views.confirm_checkout, name='confirm_checkout'),

    # Order history
    path('order-history/', views.order_history, name='order_history'),
    path('my-team/chart-view/', views.org_chart_view, name='org_chart_view'),
    path('my-team/chart-data/', views.org_chart_data, name='org_chart_data'),
    path('my-team/chart-view/', TemplateView.as_view(template_name='user/org_chart.html'), name='org_chart_view'),
    path('my-team/tabular-view/', views.tabular_team_view, name='tabular_team_view'), 
    path('payouts/', views.payout_list_view, name='payout_list'),
    path('generate-payout/', views.generate_payout_view, name='generate_payout'),
    path('leaders-summit/', views.leaders_summit_view, name='leaders_summit')
    

]