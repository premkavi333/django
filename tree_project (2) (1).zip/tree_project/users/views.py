from datetime import date
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.urls import reverse
from .forms import UserProfileForm, SignupForm ,BankDetailsForm, PanCardForm, GSTForm, IDForm, ShippingAddressForm
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from .models import Order, OrderItem, PVRecord, Payout, PvPoint, UserProfile, UserTree
from django.http import FileResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from tree_app.models import Product, Category
from .models import CartItem
from django.http import JsonResponse
from django.db.models import Sum

from django.http import HttpResponse
from users.models import UserRankStat
from django.template.loader import render_to_string
import pdfkit
from django.core.serializers.json import DjangoJSONEncoder
from django.utils.safestring import mark_safe
import json



# Dashboard view
@login_required
def dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    return render(request, 'user/dashboard.html', {'profile': profile})

# My Account -> My Profile
@login_required
def my_profile(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    return render(request, 'user/my_profile.html', {'profile': profile})

# Change Password Page
@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Keep user logged in
            messages.success(request, '✅ Your password was successfully updated!')
            return redirect('user:dashboard', request.user.id)
        else:
            messages.error(request, '❌ Please correct the errors below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'user/change_password.html', {'form': form})

# Profile Picture Page
@login_required
def profile_picture(request):
    profile = get_object_or_404(UserProfile, user_id=request.user.id)
    return render(request, 'user/profile.html', {'profile': profile})

@login_required
def visiting_card(request):
    user = get_object_or_404(UserProfile, user_id=request.user.id)
    return render(request, 'user/visiting_card.html', {'profile': user})

@login_required
def welcome_letter(request):
    user = get_object_or_404(UserProfile, user_id=request.user.id)
    return render(request, 'user/welcome_letter.html', {'profile': user})

def transaction_password(request):
    return render(request, 'user/transaction_password.html')

@login_required
def upload_profile_picture(request):
    profile = UserProfile.objects.get(user=request.user)
    
    if request.method == 'POST' and request.FILES.get('profile_image'):
        profile.profile_image = request.FILES['profile_image']
        profile.save()
        return redirect('users:upload_profile_picture')

    return render(request, 'user/upload_profile_picture.html', {
        'profile': profile
    })

@login_required
def download_welcome_letter_pdf(request):
    from django.http import FileResponse
    import os
    filepath = os.path.join('static', 'pdfs', 'welcome_letter_sample.pdf')
    return FileResponse(open(filepath, 'rb'), content_type='application/pdf')


 # or use xhtml2pdf, weasyprint, etc.

def download_card_pdf(request):
    user = get_object_or_404(UserProfile, user_id=request.user.id)
    html = render_to_string('user/visiting_card_pdf.html', {'user': user})
    
    # Option 1: Using pdfkit (ensure wkhtmltopdf is installed)
    pdf = pdfkit.from_string(html, False)
    
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="visiting_card.pdf"'
    return response

@login_required
def id_card(request):
    profile = get_object_or_404(UserProfile, user_id=request.user.id)
    return render(request, 'user/id_card.html', {'profile': profile})

# ✅ SIGNUP VIEW (Split Forms)
@login_required
def signup_view(request):
    if request.method == 'POST':
        signup_form = SignupForm(request.POST)
        profile_form = UserProfileForm(request.POST)

        if signup_form.is_valid() and profile_form.is_valid():
            username = signup_form.cleaned_data['username']
            email = signup_form.cleaned_data['email']
            password = signup_form.cleaned_data['password']

            # Check uniqueness
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already taken.')
            elif User.objects.filter(email=email).exists():
                messages.error(request, 'Email already registered.')
            else:
                # Create user
                user = User.objects.create(
                    username=username,
                    email=email,
                    password=make_password(password)
                )

                # Create profile
                profile = profile_form.save(commit=False)
                profile.user = user
                profile.sponsor_id = request.user.id
                profile.sponsor_name = request.user.get_full_name() or request.user.username
                profile.role = 0
                profile.save()

                messages.success(request, "Signup successful!")
                print("✅ Redirecting to signup success page...")
                return redirect(reverse('users:signup-success'))
        else:
            print("❌ SignupForm Errors:", signup_form.errors)
            print("❌ ProfileForm Errors:", profile_form.errors)
            messages.error(request, "Please correct the errors below.")
    else:
        signup_form = SignupForm()
        profile_form = UserProfileForm()

        # Prefill sponsor info
        profile_form.fields['sponsor_id'].initial = request.user.id
        profile_form.fields['sponsor_name'].initial = request.user.get_full_name() or request.user.username
        profile_form.fields['sponsor_position'].initial = "Left"

    return render(request, 'user/signup.html', {
        'signup_form': signup_form,
        'profile_form': profile_form
    })

# Signup Success Page
def signup_success(request):
    return render(request, 'user/signup_success.html')

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('tree_app:login')

@login_required
def update_bank_details(request):
    profile = UserProfile.objects.get(user=request.user)
    if request.method == 'POST':
        form = BankDetailsForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
        return redirect('users:update_bank_details')   # or 'dashboard'
    else:
        form = BankDetailsForm(instance=profile)
    return render(request, 'user/update_bank_details.html', {'form': form, 'profile': profile})


@login_required
def upload_pan_card(request):
    profile = request.user.userprofile  # or however you fetch the logged-in user’s profile

    if request.method == 'POST':
        form = PanCardForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'PAN details updated successfully.')
            return redirect('users:upload_pan_card')
    else:
        form = PanCardForm(instance=profile)

    return render(request, 'user/upload_pan_card.html', {
        'form': form,
        'profile': profile
    })

@login_required
def upload_gst(request):
    profile = UserProfile.objects.get(user=request.user)
    if request.method == 'POST':
        form = GSTForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ GST uploaded successfully!")
            return redirect('users:upload_gst')
    else:
        form = GSTForm(instance=profile)
    return render(request, 'user/upload_gst.html', {'form': form, 'profile': profile})

@login_required
def upload_id_proof(request):
    profile = request.user.userprofile
    if request.method == 'POST':
        form = IDForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "ID Proof updated successfully!")
            return redirect('users:upload_id_proof')
    else:
        form = IDForm(instance=profile)
    return render(request, 'user/upload_id_proof.html', {
        'form': form,
        'profile': profile
    })


@login_required
def order_now(request):
    user_profile = UserProfile.objects.get(user=request.user)
    billing_info = {
        "ird_number": user_profile.distributor_ird,
        "name": user_profile.name,
        "address": user_profile.address1,
        "state": user_profile.state,
        "city": user_profile.city,
        "pin_code": user_profile.pin_code,
        "mobile": user_profile.mobile_no,
    }

    if request.method == "POST":
        form = ShippingAddressForm(request.POST)
        if form.is_valid():
            shipping = form.save(commit=False)
            shipping.user = request.user
            shipping.save()
            return redirect('users:shop_home')  # Or next step
    else:
        form = ShippingAddressForm()

    return render(request, 'user/order_now.html', {
        'billing': billing_info,
        'form': form
    })

@login_required
def shop_home(request):
    category_id = request.GET.get('category')
    search_query = request.GET.get('search', '')

    products = Product.objects.filter(is_active=True)
    selected_category = None

    if category_id:
        try:
            selected_category = int(category_id)
            products = products.filter(category_id=selected_category)
        except Category.DoesNotExist:
            selected_category = None

    if search_query:
        products = products.filter(name__icontains=search_query)

    # ✅ Updated cart_count logic
    cart_count = 0
    if request.user.is_authenticated:
        order = Order.objects.filter(user=request.user, is_ordered=False).first()
        if order:
            cart_count = OrderItem.objects.filter(order=order).count()

    context = {
        'products': products,
        'categories': Category.objects.all(),
        'selected_category': selected_category,
        'cart_count': cart_count,
    }
    return render(request, 'user/shop_home.html', context)


@login_required
def view_cart(request):
    order = Order.objects.filter(user=request.user, is_ordered=False).first()
    cart_items = []

    total_price = 0
    total_pv_point = 0
    if order:
        cart_items = OrderItem.objects.filter(order=order)
        for item in cart_items:
            item.subtotal = item.product.dp_price * item.quantity
            total_price += item.subtotal
            total_pv_point += item.pv_point

    user_profile = request.user.userprofile  # Adjust as per your model name
    return render(request, 'user/view_cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
        'total_pv_point': total_pv_point,
        'user_profile': user_profile,
    })

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    # Existing Order logic
    order = Order.objects.filter(user=request.user, is_ordered=False).first()
    if not order:
        order = Order.objects.create(user=request.user, is_ordered=False)

    order_item, created = OrderItem.objects.get_or_create(
        order=order,
        product=product,
        defaults={
            'quantity': 1,
            'price': product.dp_price,
            'pv_point': product.pv_point
        }
    )

    if not created:
        order_item.quantity += 1
        order_item.save()

    # ✅ Sync with CartItem table
    cart_item, created = CartItem.objects.get_or_create(
        user=request.user,
        product=product,
        defaults={'quantity': 1}
    )
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    messages.success(request, f"{product.name} added to cart successfully!")
    return redirect('users:shop_home')

@login_required
def update_cart_quantity(request, product_id):
    if request.method == 'POST':
        qty = int(request.POST.get('qty', 1))  # 👈 qty from template input
        order = Order.objects.filter(user=request.user, is_ordered=False).first()
        if order:
            item = OrderItem.objects.filter(order=order, product_id=product_id).first()
            if item:
                item.quantity = qty
                item.dp_price = item.product.dp_price * qty
                item.pv_point = item.product.pv_point * qty
                item.save()
    return redirect('users:view_cart')

@login_required
def remove_from_cart(request, product_id):
    order = Order.objects.filter(user=request.user, is_ordered=False).first()
    if order:
        OrderItem.objects.filter(order=order, product_id=product_id).delete()
    return redirect('users:view_cart')

@login_required
def my_team_view(request):
    # Get the current user's profile
    current_profile = UserProfile.objects.get(user=request.user)

    # Correct field name: sponsor_id (NOT sponcer_id)
    team_members = UserProfile.objects.filter(sponsor_id=str(request.user.id))

    return render(request, 'user/my_team.html', {'team_members': team_members})

from users.models import UserProfile, UserRankStat

@login_required
def current_rank_view(request):
    profile = request.user.userprofile

    # Try to get rank data or assign default values
    try:
        rank_stat = UserRankStat.objects.get(user=request.user)
    except UserRankStat.DoesNotExist:
        rank_stat = None

    rank_info = {
        "sr_no": 1,
        "id_no": profile.distributor_ird or "NA",
        "name": profile.name or "NA",
        "current_rank": rank_stat.current_rank if rank_stat else "NA",
        "left_point": rank_stat.left_point if rank_stat else 0,
        "right_point": rank_stat.right_point if rank_stat else 0,
        "total_match": rank_stat.total_match if rank_stat else 0,
        "team_no": rank_stat.team_no if rank_stat else 0,
    }

    return render(request, "user/current_rank.html", {"rank_info": rank_info})


@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'user/order_history.html', {'orders': orders})
@login_required
def confirm_checkout(request):
    if request.method == 'POST':
        payment_receipt = request.FILES.get('payment_receipt')
        payment_method = request.POST.get('payment_method', 'upi')

        cart_items = CartItem.objects.filter(user=request.user)
        if not cart_items.exists():
            return redirect('users:view_cart')

        # ✅ Use dp_price here
        total_price = sum(item.product.dp_price * item.quantity for item in cart_items)

        order = Order.objects.create(
            user=request.user,
            total_price=total_price,
            payment_method=payment_method,
            payment_receipt=payment_receipt,
            status='pending'
        )

        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.dp_price,  # ✅ corrected field
                pv_point=item.product.pv_point * item.quantity
            )

        cart_items.delete()

        apply_pv_points(order)  # ✅ if you're using PV logic, keep this

        return redirect('users:order_history')

    return redirect('users:view_cart')



def apply_pv_points(order):
    for item in order.orderitem_set.all():
        product = item.product
        quantity = item.quantity
        total_pv = product.pv_point * quantity
        pv_obj, _ = PvPoint.objects.get_or_create(user=order.user)
        pv_obj.self_pv += total_pv
        pv_obj.save()

        propagate_pv_to_parents(order.user, total_pv)


# ✅ Updated to avoid AttributeError
def propagate_pv_to_parents(user, total_pv):
    current_tree = UserTree.objects.filter(user=user).first()

    while current_tree:
        parent = current_tree.parent
        if not parent:
            break

        position = current_tree.position  # safe now

        parent_pv, _ = PvPoint.objects.get_or_create(user=parent)
        if position == 'left':
            parent_pv.left_pv += total_pv
        elif position == 'right':
            parent_pv.right_pv += total_pv
        parent_pv.save()

        current_tree = UserTree.objects.filter(user=parent).first()

def org_chart_view(request):
    return render(request, 'user/org_chart.html')


@login_required
def tabular_team_view(request):
    logged_in_user = request.user
    try:
        root_profile = UserProfile.objects.get(user=logged_in_user)
    except UserProfile.DoesNotExist:
        return render(request, 'user/tabular_team.html', {'error': 'UserProfile not found.'})

    root_ird = root_profile.distributor_ird
    team_data = []

    def get_children(parent_ird, level):
        children = UserProfile.objects.filter(sponsor_id=parent_ird)
        for child in children:
            team_data.append({
                'level': level,
                'name': child.name,
                'distributor_ird': child.distributor_ird,
                'sponsor_id': child.sponsor_id
            })
            # Recursively find children of this child
            get_children(child.distributor_ird, chr(ord(level) + 1))  # A → B → C ...

    # Add root user (Level A)
    team_data.append({
        'level': 'A',
        'name': root_profile.name,
        'distributor_ird': root_profile.distributor_ird,
        'sponsor_id': root_profile.sponsor_id or '--'
    })

    # Add direct and indirect team recursively
    get_children(root_ird, 'B')

    return render(request, 'user/tabular_team.html', {'team_data': team_data})
    logged_in_id = request.user.username  # Assuming distributor_ird = user.username
    visited = set()

    def fetch_level_users(parent_id, level):
        children = Distributor.objects.filter(sponsor_id=parent_id)
        rows = []
        for child in children:
            if child.distributor_ird in visited:
                continue
            visited.add(child.distributor_ird)
            rows.append({
                'level': level,
                'user_id': child.distributor_ird,
                'name': child.name,
                'sponsor_id': child.sponsor_id
            })
            rows += fetch_level_users(child.distributor_ird, chr(ord(level) + 1))  # Next level
        return rows

    table_data = [{
        'level': 'A',
        'user_id': logged_in_id,
        'name': 'You',
        'sponsor_id': 'None'
    }]
    visited.add(logged_in_id)
    table_data += fetch_level_users(logged_in_id, 'B')

    return render(request, 'user/tabular_chart.html', {'table_data': table_data})

def org_chart_data(request):
    user = request.user

    try:
        root = UserProfile.objects.get(user_id=user.id)
    except UserProfile.DoesNotExist:
        return JsonResponse([], safe=False)

    nodes = []

    # Add logged-in user as root
    nodes.append({
        "id": root.user_id,
        "name": root.name,
        "title": "You",
       "img": "/static/images/profile_placeholder.png"
    })

    # Add direct team members
    team = UserProfile.objects.filter(sponsor_id=root.user_id)
    for member in team:
        nodes.append({
            "id": member.user_id,
            "pid": root.user_id,
            "name": member.name,
            "title": member.sponsor_position or "Member",
            "img": "/static/images/profile_placeholder.png"
        })

    return JsonResponse(nodes, safe=False)
 
 # views.py

from django.shortcuts import render
from .models import UserProfile

def get_downline_users(user_id, level=1, collected=None):
    if collected is None:
        collected = []

    # Filter based on string sponsor_id field
    children = UserProfile.objects.filter(sponsor_id=user_id)

    for child in children:
        collected.append({'user': child, 'level': level})
        get_downline_users(child.user_id, level + 1, collected)

    return collected

def tabular_team_view(request):
    current_user_profile = request.user.userprofile
    downlines = get_downline_users(current_user_profile.user_id)

    return render(request, 'user/tabular_team.html', {'downlines': downlines})

def payout_list_view(request):
    selected_code = request.GET.get('payout_code', '')

    # Get all unique payout codes with their periods
    payout_periods = Payout.objects.order_by('-from_date').values('payout_code', 'from_date', 'to_date').distinct()

    if selected_code:
        payouts = Payout.objects.filter(payout_code=selected_code).order_by('-from_date')
    else:
        payouts = Payout.objects.all().order_by('-from_date')

    context = {
        'payouts': payouts,
        'payout_periods': payout_periods,
        'selected_code': selected_code,
    }
    return render(request, 'user/payout_list.html', context)

def generate_payout_view(request):
    return HttpResponse("Payout generation logic goes here.")


@login_required
def leaders_summit_view(request):
    user = request.user
    current_year = date.today().year

    quarters = [
        {'name': 'Q1 (Jan-Mar)', 'start': date(current_year, 1, 1), 'end': date(current_year, 3, 31)},
        {'name': 'Q2 (Apr-Jun)', 'start': date(current_year, 4, 1), 'end': date(current_year, 6, 30)},
        {'name': 'Q3 (Jul-Sep)', 'start': date(current_year, 7, 1), 'end': date(current_year, 9, 30)},
        {'name': 'Q4 (Oct-Dec)', 'start': date(current_year, 10, 1), 'end': date(current_year, 12, 31)},
    ]

    summary = []

    for q in quarters:
        left_pv = PVRecord.objects.filter(
            user=user, date__range=(q['start'], q['end'])
        ).aggregate(Sum('left_pv'))['left_pv__sum'] or 0

        right_pv = PVRecord.objects.filter(
            user=user, date__range=(q['start'], q['end'])
        ).aggregate(Sum('right_pv'))['right_pv__sum'] or 0

        qualified = left_pv >= 3000 and right_pv >= 3000

        summary.append({
            'quarter': q['name'],
            'from': q['start'],
            'to': q['end'],
            'left_pv': left_pv,
            'right_pv': right_pv,
            'qualified': qualified
        })

    return render(request, 'user/leaders_summit.html', {'summary': summary})


